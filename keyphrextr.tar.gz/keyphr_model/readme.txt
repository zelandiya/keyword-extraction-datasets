1. Extract the model:
tar -xvvf keyphrextr.tar.gz 

2. Use the keyphrextr file in the -m option in Maui

The model was created using the training set used by the keyphrase extraction participants at SemEval-2010. The data set contained 100 ACM publications.

